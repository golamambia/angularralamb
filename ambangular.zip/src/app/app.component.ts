 
import { Component,Injectable } from '@angular/core';
import { HttpClient ,HttpHeaders,HttpParams} from '@angular/common/http';
import { catchError, map, Observable, throwError } from 'rxjs';
import { host } from '../environments/environment';
import {LocalStorageService} from 'ngx-localstorage';
import { Router } from '@angular/router';
import { AuthenticationService } from './corenw/auth/authentication.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'testpro';
  constructor(private _httpClient: HttpClient,private _storageService: LocalStorageService,
    private router: Router,private auth:AuthenticationService,
    
    ) { this.auth.isLoggedIn();}
}
