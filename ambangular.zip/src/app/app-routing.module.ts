import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './modules/dashboard/home/home.component';
import { LoginComponent } from './modules/login/login.component';
import { TestComponent } from './modules/dashboard/test/test.component';
import { OrganiserComponent } from './modules/dashboard/organiser/organiser.component';
import { PsdComponent } from './modules/dashboard/psd/psd.component';

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'login', component: LoginComponent },
  { path: 'test', component: TestComponent },
  { path: 'dashboard', loadChildren : () => import('./modules/dashboard/dashboard.module').then(m=>m.DashboardModule) },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
