export class ApiStatusCodes {
   public static SUCCESS = 200;
   public static ERROR = 400;
}


export class ValidationExpressions {
   // public static Password = /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/;
   public static Password = /^(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/;
   public static Email = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;


}


export class UnitInfoStatus {
   public static  DEFAULTSTATUS=0;
   public static CONSTRUCTIONINPROGRESS = 1;
   public static NVPISSUE = 2;
   public static PAYMENTCLEARED = 3;
   public static  HCAPPOIMNTMENTFIXED=4;



}

