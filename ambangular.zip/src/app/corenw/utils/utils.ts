import { UnitInfoStatus } from './Constants';

export class Utils {


    static getInitName(name) {
        var matches = name.match(/\b(\w)/g); // ['J','S','O','N']
        return matches.join('');

    }
    // tslint:disable-next-line: member-ordering

    static getPaymentStatus(values) {
        const CONSTRUCTIONINPROGRESS = [
            'Unit Setup', 'FA1', 'FA2', 'FA3', 'QM/Conquas',
            'Ready for Inspection', '1st Inspection', 'Final Inspection',
            'HOD Takeover', 'Unit Ready for NVP', 'NVP Prepared',
        ];
        const NVP_SERVED = ['NVP Served'];
        const PAYMENT_CLEARED = ['Payment Cleared'];
        const HC_APPOIMNTMENT_FIXED = ['Payment Cleared'];
        if (CONSTRUCTIONINPROGRESS.includes(values)) {
            return UnitInfoStatus.CONSTRUCTIONINPROGRESS;
        } else if (NVP_SERVED.includes(values)) {
            return UnitInfoStatus.NVPISSUE;
        } else if (PAYMENT_CLEARED.includes(values)) {
            return UnitInfoStatus.PAYMENTCLEARED;
        } else if (HC_APPOIMNTMENT_FIXED.includes(values)) {
            return UnitInfoStatus.HCAPPOIMNTMENTFIXED;
        } else {
            return UnitInfoStatus.DEFAULTSTATUS;
        }
    }

    // Converting Base64 (dataURI) to Uint8Array
    static convertDataURIToBinary(dataURI: any) {
        const BASE64_MARKER = ';base64,';
        const base64Index = dataURI.indexOf(BASE64_MARKER) + BASE64_MARKER.length;
        const base64 = dataURI.substring(base64Index);
        const raw = window.atob(base64);
        const rawLength = raw.length;
        const array = new Uint8Array(new ArrayBuffer(rawLength));

        for (let i = 0; i < rawLength; i++) {
        array[i] = raw.charCodeAt(i);
        }
        return array;
    }
}