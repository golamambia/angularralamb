import { Injectable } from '@angular/core';
// import { NativeStorage } from '@ionic-native/native-storage/ngx';
import { Plugins } from '@capacitor/core';

const { Storage } = Plugins;
@Injectable()
export class LocalStorageService {

  //  constructor(private nativeStorage: NativeStorage) {

  // }


  // public setItem(key: string, value: any) {
  //   this.nativeStorage.setItem(key, { property: 'value', anotherProperty: 'anotherValue' })
  //     .then(
  //       () => console.log('Stored item!'),
  //       error => console.error('Error storing item', error)
  //     );

  //   return this.nativeStorage.setItem(key, value);



  // }
  // public getItem(key: string) {
  //   this.nativeStorage.getItem(key)
  //     .then(
  //       data => console.log(data),
  //       error => console.error(error)
  //     );
  //   return this.nativeStorage.getItem(key);
  // }
  // public clearItem(key: string) {
  //   return this.nativeStorage.remove(key);
  // }
  // public clearAll() {
  //   return this.nativeStorage.clear();
  // }


  async setItem(keyItem: string, valueItem: any) {
    await Storage.set({
      key: keyItem,
      value: valueItem
    });
  }

  async getItem(keyItem: string) {
    return await Storage.get({ key: keyItem }).then(data => data.value);
  }

  async   clearItem(keyItem: string) {
    await Storage.remove({ key: keyItem });
  }

  async keys() {
    const { keys } = await Storage.keys();
    console.log('Got keys: ', keys);
  }

  async clearAll() {
    await Storage.clear();
  }
}
