import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { BehaviorSubject, catchError, map, Observable, throwError } from 'rxjs';
import { host } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class BaseService {
  private messageSource = new BehaviorSubject('default message');
  public currentMessageSubscriber = this.messageSource.asObservable();



  constructor(private _httpClient: HttpClient,

  ) { }
  notify(message: any) {
    this.messageSource.next(message)
  }
  post(url: string, body: any, headers?: HttpHeaders, token?: string, params?: HttpParams, key?: string): Observable<any> {
    // body.application = 'mobile';

    headers = headers?.append('Content-Type', 'application/json');
    // .set('Authorization', this.SetAccessToken());
    return this._httpClient.post(host+'api/', body, { params, headers, observe: 'response' }).pipe(
      map((response: any) => {
        return <any>response.body;
      }),
      catchError(e => { return throwError(this.getException(e, key)); })
    );
  }

  login(url: string, body: any, headers?: HttpHeaders, token?: string, params?: HttpParams, key?: string): Observable<any> {
    // body.application = 'mobile';

    headers = headers?.append('Content-Type', 'application/json');
    // .set('Authorization', this.SetAccessToken());
    return this._httpClient.post(host+'urm/', body, { params, headers, observe: 'response' }).pipe(
      map((response: any) => {
        return <any>response.body;
      }),
      catchError(e => { return throwError(this.getException(e, key)); })
    );
  }
  getException(e: any, key?: string) {
    if (navigator.onLine) {
      if (e && e.error && e.error.message) {
        return e;
      } else {
        return {
          status: -1,
          error: {
            title: 'Oh oh!',
            message: 'An error occured while fetching the details. Please try after sometime.'
          }
        }
      }
    } else {
      // No Internet scenario. Using Offline Mode Data (if any)

      return {
        status: -1,
        error: {
          title: 'Oh oh! No Internet!',
          message: 'Check your internet connection.'
        }
      }
    }
  }
}
