import { Component, OnInit } from '@angular/core';
import { Directive, HostListener, ElementRef } from '@angular/core';
import { HttpClient ,HttpHeaders,HttpParams} from '@angular/common/http';
import {NgbModal,ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { NgxSpinnerService } from "ngx-spinner";

import {LocalStorageService} from 'ngx-localstorage';
import { Router } from '@angular/router';
import { BaseService } from 'src/app/corenw/services/base.service';
import { AuthenticationService } from 'src/app/corenw/auth/authentication.service';
import { host } from 'src/environments/environment';
import { ValidationExpressions } from 'src/app/corenw/utils/Constants';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  res:any;

  form: FormGroup;
  logform: FormGroup;
  email:any='';
  name:any='';
  closeResult: string = '';
  submitted = false;
  submittednw = false;
  mpin:any='';
  error_message='';
  mpina:any='';
  mpinb:any='';
  mpinc:any='';
  mpind:any='';
  mpine:any='';
  mpinf:any='';
  constructor(private http: HttpClient,private modalService: NgbModal,
    private formBuilder: FormBuilder,private el: ElementRef,private spinner: NgxSpinnerService,
    private baseService:BaseService,private _storageService: LocalStorageService,
    private router: Router,private auth:AuthenticationService,
    )
  {
    this.form = this.formBuilder.group({
      password: ['', Validators.required],
      username: ['', Validators.required],
      //email: ['',  [Validators.required, Validators.email]]
    });
    this.logform = this.formBuilder.group({

       // mpin: ['', Validators.required],


    });
    this.auth.isLoggedIn();

  }

  ngOnInit(): void {
    // var ff = $(".myInput");
    // ff.keyup(function (e:any) {
    //   alert(1);
    // });
  }
  get f() {
    return this.form.controls;
  }
  get l() {
    return this.logform.controls;
  }

  onSubmit() {
  this.mpin=this.mpina+this.mpinb+this.mpinc+this.mpind+this.mpine+this.mpinf;
    this.submittednw = true;

    if (!this.mpin) {
      this.error_message='Mpin is required';
      return;
    }else{
      this.spinner.show();

      const  data={

        'user_login_id':this.form.value.username,
        'service_name':'USER_AUTHENTICATION_MOBILE',
        'password':this.form.value.password,
        'mpin':this.mpin,
      }
      
      //console.log(data);
      //JSON.stringify(data)
      this.baseService.login(host,JSON.stringify(data))
      .subscribe(response=> {
        this.spinner.hide();
      this.res = '';
      //console.log(response);
      if(response.responseStatus=='success'){
        this.error_message='';
        //console.log(response.response.authToken);
        this.baseService.notify({isRefresh : true});
        localStorage.setItem('user', JSON.stringify(response.response));
        localStorage.setItem('token', JSON.stringify(response.response.authToken));
        this.router.navigate(['/dashboard/home']);
        this.modalService.dismissAll();
      }else if(response.responseStatus=="failed"){
       // alert(''+response.response);
       this.error_message=response.response;
      }else{
        this.error_message='';
       alert('Something went wrong please try again');
      }
      }, (err:any) => {



      });
    }
  }
  open(content:any) {

    // alert(12);
    this.submitted = true;
    if (this.form.invalid) {
      return;
    }
    else{
     this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
       this.closeResult = `Closed with: ${result}`;
     }, (reason) => {
       this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
     });
   }
   }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  onDigitInput(event:any){

    let element;
    if (event.code !== 'Backspace')
         element = event.srcElement.nextElementSibling;

     if (event.code === 'Backspace')
         element = event.srcElement.previousElementSibling;

     if(element == null)
         return;
     else
         element.focus();
 }
}
