import { ChangeDetectorRef, Component, ElementRef, Inject, Input, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { PsdComponent } from '../psd.component';

@Component({
  selector: 'app-choose-hybrid',
  templateUrl: './choose-hybrid.component.html',
  styleUrls: ['./choose-hybrid.component.scss']
})
export class ChooseHybridComponent implements OnInit {
  selected : any = 0;

  type: any;
  hybridFormattedArray = [];
  @Input() selectedHybrid: any;
  // hybridData1 = []  
  hybridData1 = [
    { cropCode: "MAIZE", hybridId: 1324, seasonCode: "2022-2023", seedRateF: 2.9, seedRateM: 3.85, varietyCode: "MMEH-5" },
    { cropCode: "MAIZE", hybridId: 1423, seasonCode: "2022-2023", seedRateF: 3.2, seedRateM: 5.6, varietyCode: "MMEH-6" },
    { cropCode: "PADDY", hybridId: 2143, seasonCode: "2022-2023", seedRateF: 3.8, seedRateM: 4.2, varietyCode: "MREH-66" },
    { cropCode: "PADDY", hybridId: 2431, seasonCode: "2022-2023", seedRateF: 3.7, seedRateM: 4.8, varietyCode: "MREH-3" },
    { cropCode: "MAIZE", hybridId: 3214, seasonCode: "2022-2023", seedRateF: 5.5, seedRateM: 4.5, varietyCode: "MMH-38" },
    { cropCode: "PADDY", hybridId: 4123, seasonCode: "2022-2023", seedRateF: 3.5, seedRateM: 4.65, varietyCode: "MREH4-45" },
  ]

  //@ViewChild('scroll') scroll: any;
  @ViewChild('scroll', { read: ElementRef })
  public scroll!: ElementRef<any>;
  orgPsdData: any;

  constructor( public dialogRef: MatDialogRef<PsdComponent>,
    private cdr: ChangeDetectorRef) { }

  public scrollRight(): void {
    this.scroll.nativeElement.scrollTo({ left: (this.scroll.nativeElement.scrollLeft - 150), behavior: 'smooth' });
  }

  public scrollLeft(): void {
    this.scroll.nativeElement.scrollTo({ left: (this.scroll.nativeElement.scrollLeft + 150), behavior: 'smooth' });

  }
  hybridFormattedArray1 :{ type: string, values: string[] }[]  = []
  ngOnInit() {
   
    var groups :any = {};
    for (var i = 0; i < this.hybridData1.length; i++) {
      
        var cropCode = this.hybridData1[i].cropCode.toLowerCase();
        if (!groups[cropCode.toLowerCase()]) {
          groups[cropCode] = [];
        }
        groups[cropCode.toLowerCase()].push(this.hybridData1[i]);
     

    }

    for (var groupName in groups) {
      this.hybridFormattedArray1.push({ type: groupName, values: groups[groupName] });
    }
    console.log(this.hybridFormattedArray1)


    if (this.selectedHybrid) {
      this.type = this.selectedHybrid.hybrid[0].cropCode;
    } else {
      this.type = this.hybridFormattedArray1[0].type;
    }

  }



  segmentChanged(ev: any) {
    if (!this.type) {
      this.type = this.hybridFormattedArray1[0].type;
    } else {
      this.type = ev.target.value;
    }
  }

  ngAfterViewChecked() {
    this.cdr.detectChanges();
  }

  selectHybrid(value) {
    this.dialogRef.close({'selectedHybrid': value});
  }
  splitCode(code) {
    var fields = code.split('-');
    var hybridname = fields[0];
    return hybridname;
  }

  getHybridCode(code) {
    var fields = code.split('-');

    var hybridCode = fields[1];
    return hybridCode;
  }

}
