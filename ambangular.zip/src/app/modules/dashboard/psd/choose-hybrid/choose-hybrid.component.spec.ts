import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChooseHybridComponent } from './choose-hybrid.component';

describe('ChooseHybridComponent', () => {
  let component: ChooseHybridComponent;
  let fixture: ComponentFixture<ChooseHybridComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChooseHybridComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChooseHybridComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
