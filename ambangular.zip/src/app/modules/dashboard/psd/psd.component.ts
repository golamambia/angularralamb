import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { BaseService } from 'src/app/corenw/services/base.service';
import { ChooseBatchComponent } from './choose-batch/choose-batch.component';
import { ChooseHybridComponent } from './choose-hybrid/choose-hybrid.component';
import { HttpHeaders } from '@angular/common/http';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatSnackBar } from '@angular/material/snack-bar';
import { EditPsdComponent } from './edit-psd/edit-psd.component';

@Component({
  selector: 'app-psd',
  templateUrl: './psd.component.html',
  styleUrls: ['./psd.component.scss']
})
export class PsdComponent implements OnInit {

  displayedColumns: string[] = ['cropCode', 'hybrid', 'batchNumber', 'issuedUnit',
    'placementUnit', 'damagedUnit', 'balanceUnitHand',
    'soakingUnit', 'balanceUnitPlacement', 'returnUnitPlacement',
    'totalPkt', 'companyReturn', 'reconStatus', 'action'];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  selectedCrop: any
  hybrid: any;
  batch: any;
  organiserData: any;

  selectedSeedType: any;
  hybridMasterList: any;
  hybridBatchesList: any;
  organiserAllPsdDetails: any;

  selectedHybrid: any;
  selectedBatchDetails: any;
  issuedUnits: any;
  placementUnits: any;
  damagedUnits: any;
  balanceUnitsInHand: any;
  soakingUnits: any;
  balanceUnitsFromPlacement: any;
  returnUnitsFromPlacement: any;
  totalAvailablePkts: any;
  returnToCompany: any;
  reconcilationStatus: any;
  refreshDataInterval: any;
  showEditBtn: boolean;
  editRowData: any;
  submitBtnFlag: boolean;
  loggedInUserData: any;


  constructor(private cdr: ChangeDetectorRef, public dialog: MatDialog,
    private router: Router, private baseService: BaseService,
    private route: ActivatedRoute,
    private _snackBar: MatSnackBar) { }

  // {
  // 	"placementUnit": 45,
  // 	"totalPkt": 12,
  // 	"balanceUnitHand": 5,
  // 	"orgSeedId": 180,
  // 	"seasonCode": "2021-2022",
  // 	"companyReturn": 56,
  // 	"hybridType": "MRH-5",
  // 	"hybridId": 4,
  // 	"soakingUnitPlacement": 56,
  // 	"balanceUnitPlacement": 43,
  // 	"reconStatus": "2",
  // 	"orgId": "RALLIS",
  // 	"issuedUnit": 80,
  // 	"soakingUnit": 0,
  // 	"damagedUnit": 0,
  // 	"returnUnitPlacement": 69,
  // 	"batchNumber": "B7324"
  // },
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  ngOnInit(): void {
    this.submitBtnFlag = true;
    this.showEditBtn = true;
    this.organiserAllPsdDetails = null;
    this.dataSource = null;
    console.log(history.state.organiserData)
    this.loggedInUserData = JSON.parse(localStorage.getItem('user'))
    console.log('loggedInUserData', this.loggedInUserData);
    if (history.state.organiserData) {
      this.organiserData = history.state.organiserData;
      console.log('organiserData >>', this.organiserData);
      this.selectedCrop = "PADDY"
      this.getHybridMaster(this.selectedCrop);
      this.getOrganiserAllPsdDetails();
      this.refreshDataInterval = setInterval(() => {
        this.getOrganiserAllPsdDetails();
      }, 5000);

    } else {
      this.router.navigate(
        ['../organiser'], { relativeTo: this.route });
    }
    // else{
    //   this.router.navigate(
    //     ['../organiser'], { relativeTo: this.route });
    // }
  }
  ngOnDestroy() {
    if (this.refreshDataInterval) {
      clearInterval(this.refreshDataInterval);
    }
  }

  // chooseHybrid() {
  //   const dialogRef = this.dialog.open(ChooseHybridComponent);

  //   dialogRef.afterClosed().subscribe(result => {
  //     console.log(result);
  //     if (result) {
  //       this.selectedHybrid = result.selectedHybrid;
  //       this.hybrid = result.selectedHybrid.varietyCode
  //     }
  //   });
  // }

  // chooseBatch() {
  //   const dialogRef = this.dialog.open(ChooseBatchComponent);

  //   dialogRef.afterClosed().subscribe(result => {
  //     console.log(result);
  //     if (result) {
  //       this.selectedBatchDetails = result.selectedBatchDetails;
  //       this.batch = result.selectedBatchDetails.batchNumber
  //     }
  //   });
  // }
  selectHybrid() {
    console.log('selected hybrid', this.selectedHybrid);
    this.getHybridBatches(this.selectedHybrid.hybridId);
    this.validate()
  }

  selectBatch() {
    console.log('selected Batch Details for selected hybrid', this.selectedBatchDetails);
    let msg = `Total available packets : ${this.selectedBatchDetails.totalPkt}`
    this.openSnackBar(msg)
    this.validate()
  }
  selectedCropType() {
    console.log(this.selectedCrop);
  }

  getHybridMaster(selectedCrop) {
    this.hybridMasterList = null;
    this.hybridBatchesList = null;
    this.selectedHybrid = null;
    this.selectedBatchDetails = null;
    let headers = new HttpHeaders({
      service_name: 'GET_HYBRID_MASTER',
      auth_token: "Tp7sF6vn+GLSZM5mi+HNt7cGBpTMdhJfymvNMisLvGI=",
      user_login_id: 'tfa_5',
      org_code: 'RALLIS',
      orgId: 'RALLIS',
      cropCode: selectedCrop
    });
    let body={
      service_name: 'GET_HYBRID_MASTER',
      auth_token: this.loggedInUserData.authToken,
      user_login_id: this.loggedInUserData.userLoginId,
      org_code: 'RALLIS',
      orgId: 'RALLIS',
      cropCode: selectedCrop
    }

    // this.baseService.post('', body).subscribe((response) => {
    this.baseService.post('', '', headers).subscribe((response) => {
      if (response.responseCode === "200") {
        this.hybridMasterList = response.response;
        console.log('getHybridMaster', this.hybridMasterList);

      }
    },
      (error) => {

      }
    )
  }


  getHybridBatches(selectedHybrid) {
    this.hybridBatchesList = null;
    this.selectedBatchDetails = null;
    let headers = new HttpHeaders({
      service_name: 'GET_HYBRID_BATCH',
      auth_token: "Tp7sF6vn+GLSZM5mi+HNt7cGBpTMdhJfymvNMisLvGI=",
      user_login_id: 'tfa_5',
      org_code: 'RALLIS',
      orgId: 'RALLIS',
      hybridId: String(selectedHybrid)
    });
    let body={
      service_name: 'GET_HYBRID_BATCH',
      auth_token: this.loggedInUserData.authToken,
      user_login_id: this.loggedInUserData.userLoginId,
      org_code: 'RALLIS',
      orgId: 'RALLIS',
      hybridId: String(selectedHybrid) 
    }
    // this.baseService.post('', body).subscribe((response) => {
    this.baseService.post('', '', headers).subscribe((response) => {
      if (response.responseCode === "200") {
        this.hybridBatchesList = response.response;
        if (this.hybridBatchesList.lenght === 0) {
          let msg = "Batches are not available for selected hybrid";
          this.openSnackBar(msg);
        }
        console.log('getHybridBatches', this.hybridBatchesList);

      } else {
        let msg = "Batches are not available for selected hybrid";
        this.openSnackBar(msg);
      }
    },
      (error) => {

      }
    )
  }
  // GET_ORGANISER_PSD
  getOrganiserAllPsdDetails() {
    let headers = new HttpHeaders({
      service_name: 'GET_ORGANISER_PSD',
      // auth_token: this.loggedInUserData.authToken,
      // user_login_id: this.loggedInUserData.userLoginId,
      auth_token: "Tp7sF6vn+GLSZM5mi+HNt7cGBpTMdhJfymvNMisLvGI=",
      user_login_id: 'tfa_5',
      org_code: 'RALLIS',
      orgId: 'RALLIS',
      // seasonCode: '2021-2022',
      organiserId: String(this.organiserData.organiserId)
      //  organiserId: String(172)
    });

    let body={
      service_name: 'GET_ORGANISER_PSD',
      auth_token: this.loggedInUserData.authToken,
      user_login_id: this.loggedInUserData.userLoginId,
      org_code: 'RALLIS',
      orgId: 'RALLIS',
      // seasonCode: '2021-2022',
      organiserId: String(this.organiserData.organiserId)
      //  organiserId: String(172)
    }

    // this.baseService.post('', body).subscribe((response) => {
    this.baseService.post('', '', headers).subscribe((response) => {
      if (response.responseCode === "200") {
        this.organiserAllPsdDetails = response.response;
        console.log('getOrganiserAllPsdDetails', this.organiserAllPsdDetails);
        this.dataSource = new MatTableDataSource(this.organiserAllPsdDetails);
        console.log(this.dataSource.data.length);

        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;

      }
    },
      (error) => {

      }
    )
  }
  issueUnitEvent(selectedBatchDetails) {
   // console.log();
    
    if (this.issuedUnits > selectedBatchDetails.totalPkt) {
      let msg = `Value can not be more than ${selectedBatchDetails.totalPkt}`
      this.openSnackBar(msg);
      this.submitBtnFlag = true;
    } else if (this.issuedUnits == 0) {
      let msg = `Value can not be 0`
      this.openSnackBar(msg);
      this.submitBtnFlag = true;
    } else {
      this.validate()
    }
  }

  calculateBalanceUnitInHand() {
    this.balanceUnitsInHand = parseInt(this.issuedUnits) - (parseInt(this.placementUnits) + parseInt(this.damagedUnits))
  }
  calculateTotalAvailablePkts() {
    this.totalAvailablePkts = (parseInt(this.balanceUnitsInHand) + (parseInt(this.returnUnitsFromPlacement))) - parseInt(this.returnToCompany)
    if (parseInt(this.totalAvailablePkts) === 0) {
      this.reconcilationStatus = 'YES'
    } else {
      this.reconcilationStatus = 'NO'
    }
  }
  submitData() {
    // 
    let headers = new HttpHeaders({

      service_name: 'MANAGE_ORGANISER_PSD',
      user_login_id: 'tfa_5',
      auth_token: "Tp7sF6vn+GLSZM5mi+HNt7cGBpTMdhJfymvNMisLvGI=",
      org_code: 'RALLIS',
      orgId: 'RALLIS',
      seasonCode: String(this.selectedHybrid.seasonCode),
      organiserId: String(this.organiserData.organiserId),
      hybridId: String(this.selectedHybrid.hybridId),
      hybridType: String(this.selectedHybrid.varietyCode),
      batchNo: String(this.selectedBatchDetails.batchNumber),
      issuedUnit: String(this.issuedUnits),
      // soakingUnit: String(this.soakingUnits),
      // placementUnit: String(this.placementUnits),
      // damagedUnit: String(this.damagedUnits),
      // balanceUnitHand: String(this.balanceUnitsInHand),
      // soakingUnitPlacement: '',
      // balanceUnitPlacement: String(this.balanceUnitsFromPlacement),
      // totalPkt: String(this.totalAvailablePkts),
      // companyReturn: String(this.returnToCompany),
      // returnUnitPlacement: String(this.returnUnitsFromPlacement),
      // reconStatus: String(this.reconcilationStatus)



    });


    let body={
      service_name: 'MANAGE_ORGANISER_PSD',
      auth_token: this.loggedInUserData.authToken,
      user_login_id: this.loggedInUserData.userLoginId,
      org_code: 'RALLIS',
      orgId: 'RALLIS',
      seasonCode: String(this.selectedHybrid.seasonCode),
      organiserId: String(this.organiserData.organiserId),
      hybridId: String(this.selectedHybrid.hybridId),
      hybridType: String(this.selectedHybrid.varietyCode),
      batchNo: String(this.selectedBatchDetails.batchNumber),
      issuedUnit: String(this.issuedUnits),
    }

    // this.baseService.post('', body).subscribe((response) => {
    this.baseService.post('', '', headers).subscribe((response) => {
      if (response.responseCode === "200") {
        let msg = 'Details saved successfully';
        this.openSnackBar(msg);
        this.clearForm();
        console.log('submitData', response.response);
        this.getOrganiserAllPsdDetails();

      }
      //else {
      //   this.openSnackBar('Failed: ' + 'Please check values.');
      // }
    },
      (error) => {
        this.openSnackBar('ERROR: ' + 'Please check values.');
      }
    )
  }
  edit(row) {
    this.showEditBtn = false;
    this.editRowData = row;
    const dialogRef = this.dialog.open(EditPsdComponent, {
      data: row,
      disableClose: true,
      width: '40vw'
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The dialog was closed', result);
      // if (result.responseCode === '200') {
      this.getOrganiserAllPsdDetails();
      //  }
      // this.animal = result;
    });

  }
  save(row) {
    this.showEditBtn = true;
  }
  cancel(row) {
    this.showEditBtn = true;
  }
  clearForm() {
    this.selectedHybrid = null;
    this.selectedBatchDetails = null;
    this.issuedUnits = null;
    this.damagedUnits = null;
    this.returnToCompany = null;
  }
  openSnackBar(message) {
    this._snackBar.open(message, 'X', { duration: 2500 });
  }
  keyPress(e) {
    var txt = String.fromCharCode(e.which);
    if (!txt.match(/[0-9]/)) {
      return false;
    }
  }

  validate() {
    if (this.selectedHybrid !== null && this.selectedBatchDetails !== null && this.issuedUnits !== null) {
      this.submitBtnFlag = false;
      
    } else {
      this.submitBtnFlag = true;
    }

  }


  // user_login_id
  // service_name:GET_HYBRID_STAGGERING
  // auth_token
  // org_code
  // hybridId(mandatory)
  // orgId(mandatory)
  // locCode(mandatory)

  // user_login_id
  // service_name:GET_ALL_HYBRID_DETAILS
  // auth_token
  // org_code
  // seasonCode(mandatory)
  // orgId(mandatory)

  //GET_ORGANISER_PSD

  // user_login_id: admin_rallis
  // auth_token: /3vZexp3id3Sd1Ei/WgX8xc2ctqfgCzuxX8oQyW/WJ8=
  // org_code: RALLIS
  // service_name: GET_ORGANISER_PSD
  // seasonCode: 2021-2022
  // organiserId: 106
  // orgId: RALLIS


}
