import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditPsdComponent } from './edit-psd.component';

describe('EditPsdComponent', () => {
  let component: EditPsdComponent;
  let fixture: ComponentFixture<EditPsdComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EditPsdComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditPsdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
