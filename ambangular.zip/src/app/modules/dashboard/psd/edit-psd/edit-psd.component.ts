import { HttpHeaders } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { BaseService } from 'src/app/corenw/services/base.service';

@Component({
  selector: 'app-edit-psd',
  templateUrl: './edit-psd.component.html',
  styleUrls: ['./edit-psd.component.scss']
})
export class EditPsdComponent implements OnInit {
  editOrgPsdData: any;
  organiserData: any;
  loggedInUserData: any;

  constructor(private baseService: BaseService,
    public dialogRef: MatDialogRef<EditPsdComponent>,
    @Inject(MAT_DIALOG_DATA) public data,
    private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.loggedInUserData = JSON.parse(localStorage.getItem('user'))
    console.log('loggedInUserData', this.loggedInUserData);
    console.log('EditPsdComponent', this.data);
    this.editOrgPsdData = this.data
    if (history.state.organiserData) {
      this.organiserData = history.state.organiserData;
      console.log('organiserData >>', this.organiserData)

    }

  }
  cancelEdit(): void {
    this.dialogRef.close();
  }

  submitData() {
    console.log(this.editOrgPsdData);


    let headers = new HttpHeaders({

      service_name: 'MANAGE_ORGANISER_PSD',
      user_login_id: 'tfa_5',
      auth_token: "Tp7sF6vn+GLSZM5mi+HNt7cGBpTMdhJfymvNMisLvGI=",
      org_code: 'RALLIS',
      orgId: 'RALLIS',
      seasonCode: String(this.editOrgPsdData.seasonCode),
      organiserId: String(this.organiserData.organiserId),
      hybridId: String(this.editOrgPsdData.hybridId),
      hybridType: String(this.editOrgPsdData.hybridType),
      batchNo: String(this.editOrgPsdData.batchNumber),
      orgSeedId: String(this.editOrgPsdData.orgSeedId),
      issuedUnit: String(this.editOrgPsdData.issuedUnit),
      soakingUnit: String(this.editOrgPsdData.soakingUnit),
      placementUnit: String(this.editOrgPsdData.placementUnit),
      damagedUnit: String(this.editOrgPsdData.damagedUnit),
      balanceUnitHand: String(this.editOrgPsdData.balanceUnitHand),
      // soakingUnitPlacement: '',
      balanceUnitPlacement: String(this.editOrgPsdData.balanceUnitPlacement),
      totalPkt: String(this.editOrgPsdData.totalPkt),
      companyReturn: String(this.editOrgPsdData.companyReturn),
      returnUnitPlacement: String(this.editOrgPsdData.returnUnitPlacement),
      // reconStatus: String(this.editOrgPsdData.reconStatus)

    });

    let body={
      service_name: 'MANAGE_ORGANISER_PSD',
      auth_token: this.loggedInUserData.authToken,
      user_login_id: this.loggedInUserData.userLoginId,
      org_code: 'RALLIS',
      orgId: 'RALLIS',
      seasonCode: String(this.editOrgPsdData.seasonCode),
      organiserId: String(this.organiserData.organiserId),
      hybridId: String(this.editOrgPsdData.hybridId),
      hybridType: String(this.editOrgPsdData.hybridType),
      batchNo: String(this.editOrgPsdData.batchNumber),
      orgSeedId: String(this.editOrgPsdData.orgSeedId),
      issuedUnit: String(this.editOrgPsdData.issuedUnit),
      soakingUnit: String(this.editOrgPsdData.soakingUnit),
      placementUnit: String(this.editOrgPsdData.placementUnit),
      damagedUnit: String(this.editOrgPsdData.damagedUnit),
      balanceUnitHand: String(this.editOrgPsdData.balanceUnitHand),
      // soakingUnitPlacement: '',
      balanceUnitPlacement: String(this.editOrgPsdData.balanceUnitPlacement),
      totalPkt: String(this.editOrgPsdData.totalPkt),
      companyReturn: String(this.editOrgPsdData.companyReturn),
      returnUnitPlacement: String(this.editOrgPsdData.returnUnitPlacement),
      // reconStatus: String(this.editOrgPsdData.reconStatus)
    }
    this.baseService.post('', body).subscribe((response) => {
    // this.baseService.post('', '', headers).subscribe((response) => {
      if (response.responseCode === "200") {
        let msg = 'Details updated successfully';
        this.openSnackBar(msg);
        // let result = { result: response.response, responseCode: response.responseCode }
        this.dialogRef.close();
        // this.clearForm();
        console.log('submitData', response.response);
        // this.getOrganiserAllPsdDetails();

      } else {
        this.openSnackBar('Failed: ' + 'Please check values.');
        // let result = { result: response.response, responseCode: response.responseCode }
        // setTimeout(() => {
       // this.dialogRef.close();
        // }, 2600);

      }
    },
      (error) => {
        this.openSnackBar('ERROR: ' + error);
      }
    )
  }

  openSnackBar(message) {
    this._snackBar.open(message, 'X', { duration: 2500 });
  }
  keyPress(e) {
    var txt = String.fromCharCode(e.which);
    if (!txt.match(/[0-9]/)) {
      return false;
    }
  }


}
