import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { PsdComponent } from '../psd.component';

@Component({
  selector: 'app-choose-batch',
  templateUrl: './choose-batch.component.html',
  styleUrls: ['./choose-batch.component.scss']
})
export class ChooseBatchComponent implements OnInit {
  batchArray = [];
  genderType = 'female'
  constructor(public dialogRef: MatDialogRef<PsdComponent>) {
    this.batchArray = [
      {batchNumber : '000897981'},
      {batchNumber : '000897982'},
      {batchNumber : '000897983'},
      {batchNumber : '000897984'},
    ]
   }

  ngOnInit(): void {
  }

  selectBatch(value){
    this.dialogRef.close({'selectedBatch': value});

  }
  
}
