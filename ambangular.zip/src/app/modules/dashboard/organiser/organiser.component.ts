import { HttpHeaders } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { BaseService } from 'src/app/corenw/services/base.service';

@Component({
  selector: 'app-organiser',
  templateUrl: './organiser.component.html',
  styleUrls: ['./organiser.component.scss']
})
export class OrganiserComponent implements OnInit {
  displayedColumns: string[] = ['OrganiserId', 'Name', 'Email', 'PanNumber',
    'Status', 'Verification', 'PSD',];
  dataSource: MatTableDataSource<any>;

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  orgniserList: Array<any> = []
  loggedInUserData: any;
  constructor(private baseService: BaseService,
    private route: ActivatedRoute,
    private router: Router,
    private _snackBar: MatSnackBar) { }

  ngOnInit(): void {
    this.dataSource = null;
    this.loggedInUserData = JSON.parse(localStorage.getItem('user'))
    console.log('loggedInUserData', this.loggedInUserData);
    this.getOrganizerData()


  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  getOrganizerData() {
    console.log('hiit')
    let headers = new HttpHeaders({

      'service_name': 'SERVICE_GET_ALL_ORGANISER_LIST',

      'pageSize': '1000',

      'pageNo': '0',
      'auth_token': "Tp7sF6vn+GLSZM5mi+HNt7cGBpTMdhJfymvNMisLvGI=",
      'user_login_id': 'tfa_5',
      'org_code': 'RALLIS',

      'languageId': '3',

      'orgId': 'RALLIS',

      'orgGroup': 'RALLIS',
      'role_id': '28'
    });
    // let headers = new HttpHeaders({
    //   'service_name': 'SERVICE_GET_ALL_ORGANISER_LIST',
    //   'pageSize': '1000',
    //   'pageNo': '0',
    //   'auth_token': this.loggedInUserData.authToken,
    //   'user_login_id': this.loggedInUserData.userLoginId,
    //   'org_code': 'RALLIS',
    //   'languageId': '3',
    //   'orgId': 'RALLIS',
    //   'orgGroup': 'RALLIS',
    //   'role_id': String(this.loggedInUserData.roleId)
    // });

    let body = {
      'service_name': 'SERVICE_GET_ALL_ORGANISER_LIST',
      'pageSize': '1000',
      'pageNo': '0',
      'auth_token': this.loggedInUserData.authToken,
      'user_login_id': this.loggedInUserData.userLoginId,
      'org_code': 'RALLIS',
      'languageId': '3',
      'orgId': 'RALLIS',
      'orgGroup': 'RALLIS',
      'role_id': String(this.loggedInUserData.roleId)
    }
    // this.baseService.post('', body).subscribe((response) => {
    this.baseService.post('', '', headers).subscribe((response) => {
      if (response.responseCode === "200") {
        console.log(response)

        this.orgniserList = response.response;
        this.dataSource = new MatTableDataSource(this.orgniserList);
        console.log(this.dataSource.data.length);

        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
    },
      (error) => {

      }
    )
  }
  goToPSDistribution(organiserData: any) {
    this.router.navigate(
      ['../psd'], { state: { organiserData: organiserData }, relativeTo: this.route });
  }

  organiserVerifcation(organiserData, status) {
    console.log(organiserData, status);
    let remark = null;
    if (status.toLowerCase() === 'approve') {
      status = 'APPROVED',
        remark = 'approved'

    } else {
      status = 'REJECTED',
        remark = 'rejected'
    }
    debugger
    let headers = new HttpHeaders({

      'service_name': 'APPROVE_ORGANISER',
      'auth_token': "Tp7sF6vn+GLSZM5mi+HNt7cGBpTMdhJfymvNMisLvGI=",
      'user_login_id': 'tfa_5',
      'org_code': 'RALLIS',
      'orgId': 'RALLIS',
      'organiserId': String(organiserData.organiserId),
      'updatedBy': 'tfa_5',
      'remarks': remark,
      'approverFor': status
    });





    // let headers = new HttpHeaders({
    //   'service_name': 'APPROVE_ORGANISER',
    //   'auth_token': this.loggedInUserData.authToken,
    //   'user_login_id': this.loggedInUserData.userLoginId,
    //   'org_code': 'RALLIS',
    //   'orgId': 'RALLIS',
    //   'organiserId': organiserData.organiserId,
    //   'updatedBy': this.loggedInUserData.,
    //   'remarks': remark,
    //   'approverFor': status
    // });

    let body = {
      'service_name': 'APPROVE_ORGANISER',
      'auth_token': this.loggedInUserData.authToken,
      'user_login_id': String(this.loggedInUserData.userLoginId),
      'org_code': 'RALLIS',
      'orgId': 'RALLIS',
      'organiserId': String(organiserData.organiserId),
      'updatedBy': this.loggedInUserData.firstName,
      'remarks': remark,
      'approverFor': status

    }
    debugger
    // this.baseService.post('', body).subscribe((response) => {
    this.baseService.post('', '', headers).subscribe((response) => {
      if (response.responseCode === "200") {
        console.log('APPROVE_ORGANISER success >', response)
        this.openSnackBar('Status Changed')
        this.getOrganizerData();
      } else {
        console.log('APPROVE_ORGANISER failure >', response)
        this.openSnackBar('Falied.')
      }
    },
      (error) => {
        console.log('APPROVE_ORGANISER error >', error)

      }
    )

  }

  openSnackBar(message) {
    this._snackBar.open(message, 'X', { duration: 2500 });
  }

}
