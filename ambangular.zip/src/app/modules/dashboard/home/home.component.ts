import { Component, OnInit } from '@angular/core';
import { Directive, HostListener, ElementRef } from '@angular/core';
import { HttpClient ,HttpHeaders,HttpParams} from '@angular/common/http';
import {NgbModal,ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
 
import { NgxSpinnerService } from "ngx-spinner";
import { BaseService } from '../../../corenw/services/base.service';
import {LocalStorageService} from 'ngx-localstorage';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/corenw/auth/authentication.service';
  

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  userData:any;
  hover_status:boolean=false;
  hover_no1:boolean=false;
  hover_no2:boolean=false;
  hover_no3:boolean=false;
  hover_no4:boolean=false;
  hover_no5:boolean=false;
  hover_no6:boolean=false;
  hover_no7:boolean=false;
  hover_no8:boolean=false;
  hover_no9:boolean=false;
  hover_no10:boolean=false;
  hover_no11:boolean=false;
  hover_no12:boolean=false;

  constructor(private http: HttpClient,private modalService: NgbModal,
    private formBuilder: FormBuilder,private el: ElementRef,private spinner: NgxSpinnerService,
    private baseService:BaseService,private _storageService: LocalStorageService,
    private router: Router,private auth:AuthenticationService,
    ) 
  { 
    //this.auth.isLoggedIn();
  //  this.userData=this.auth.getUser();
    //console.log(this.userData);
  }

  ngOnInit(): void {
  }
   

}
