import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './dashboard.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { HomeComponent } from './home/home.component';
import { PsdComponent } from './psd/psd.component';
import { OrganiserComponent } from './organiser/organiser.component';
import { ChooseHybridComponent } from './psd/choose-hybrid/choose-hybrid.component';
import { AngularMaterialModule } from 'src/app/angular-material/angular-material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ChooseBatchComponent } from './psd/choose-batch/choose-batch.component';
import { ReportsComponent } from './reports/reports.component';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTableModule } from '@angular/material/table';
import { EditPsdComponent } from './psd/edit-psd/edit-psd.component';
import { MatDialogModule } from '@angular/material/dialog';


@NgModule({
  declarations: [
    DashboardComponent,HomeComponent,PsdComponent,OrganiserComponent, ChooseHybridComponent, ChooseBatchComponent, ReportsComponent, EditPsdComponent
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    DashboardRoutingModule,
    SharedModule,
    AngularMaterialModule,
    MatSnackBarModule,
    MatButtonModule,
    MatIconModule,
    MatTableModule,
    MatDialogModule
  ]
})
export class DashboardModule { }
