import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-fieldset',
  templateUrl: './custom-fieldset.component.html',
  styleUrls: ['./custom-fieldset.component.scss']
})
export class CustomFieldsetComponent implements OnInit {


  @Input() label: string = '';
  @Input() secondaryLabel: string = '';
  @Input() secondaryLabelHighlight: boolean = false;
  @Input() middleLabel: string = '';
  @Input() middleLabelHighlight: boolean = false;;
  @Input() type: string = '';
  @Input() isReadOnly: boolean = false;;
  @Input() responsiveHeight: boolean = false;;
  constructor() { }

  ngOnInit() { }
}
