import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomFieldsetComponent } from './custom-fieldset.component';

describe('CustomFieldsetComponent', () => {
  let component: CustomFieldsetComponent;
  let fixture: ComponentFixture<CustomFieldsetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CustomFieldsetComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomFieldsetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
