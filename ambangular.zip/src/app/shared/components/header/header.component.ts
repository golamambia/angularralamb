import { Component, OnInit } from '@angular/core';
import { Directive, HostListener, ElementRef } from '@angular/core';
import { HttpClient ,HttpHeaders,HttpParams} from '@angular/common/http';
import {NgbModal,ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
 import { NgxSpinnerService } from "ngx-spinner";
 
import {LocalStorageService} from 'ngx-localstorage';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/corenw/auth/authentication.service';
import { BaseService } from 'src/app/corenw/services/base.service';
 

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  userData:any='';
  constructor(private http: HttpClient,private modalService: NgbModal,
    private formBuilder: FormBuilder,private el: ElementRef,private spinner: NgxSpinnerService,
    private baseService:BaseService,private _storageService: LocalStorageService,
    private router: Router,private auth:AuthenticationService,
    ) 
  { //this.auth.isLoggedIn();
    this.userData=this.auth.isLoggedIn()?this.auth.getUser():'';
    
  }

  // ngOnInit(): void {
  // }
  ngOnInit() {
    this.baseService.currentMessageSubscriber.subscribe((data : any)=>{
      if(data.isRefresh ){
        //console.log('good');
        this.userData=this.auth.getUser();

       }
    }) 
   }
 logout() {
  this.userData='';
  this.auth.logout();
}
home() {
  //alert(1);
 // this.router.navigate(['/home1']);
}
}
