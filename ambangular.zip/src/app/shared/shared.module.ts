import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CustomFieldsetComponent } from './components/custom-fieldset/custom-fieldset.component';
import { HeaderComponent } from './components/header/header.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NumberOnlyDirective } from './directive/number-only.directive';



@NgModule({
  declarations: [
    CustomFieldsetComponent,HeaderComponent, NumberOnlyDirective
  ],
  exports:[
    CustomFieldsetComponent,HeaderComponent,NumberOnlyDirective
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ]
})
export class SharedModule { }
