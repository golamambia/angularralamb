export const environment = {
  production: true
};
// export const host = 'https://rallis.tcsdfi.tcsapps.in/ServiceGateway/servicegateway/';
// export const host ='http://10.10.134.210:8068/ServiceGateway/servicegateway/api/'

// iva
export const host = 'http://10.10.165.161:8078/ServiceGateway/servicegateway/';

// aws
// export const host = 'https://test.nonprod.rallis.tcsdfi.tcsapps.in/ServiceGateway/servicegateway/urm/';
// export const host = 'https://test.nonprod.rallis.tcsdfi.tcsapps.in/ServiceGateway/servicegateway/';
// export const host = 'http://sg.sit.svc.cluster.local/ServiceGateway/servicegateway/';